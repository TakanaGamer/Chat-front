package edu.ifam.dra.chatfront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatFrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
